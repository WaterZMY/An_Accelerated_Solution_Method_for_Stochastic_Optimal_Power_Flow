function [Expression, x] = NN_Expression(net)
Num = net.inputs{1}.size;   

%% Parameter of the Net
% Input 
x1_step1.xoffset = net.inputs{1}.range(:, 1);
x1_step1.gain = 2./(net.inputs{1}.range(:, 2)-net.inputs{1}.range(:, 1));
x1_step1.ymin = -1;

% Hidden layer
b1 = net.b{1};
IW1_1 = net.IW{1};

% Output layer
b2 = net.b{2};
LW2_1 = net.LW{2,1};

% Output
y1_step1.ymin = -1;
y1_step1.gain = 2/(net.outputs{2}.range(2)-net.outputs{2}.range(1));
y1_step1.xoffset = net.outputs{2}.range(1);

%% ===== SIMULATION ========
x = sym('x', [Num, 1]);
xp1 = x;
% Input 
xp1 = mapminmax_apply(x,x1_step1);

% Hidden Layer 
a1 = tansig_apply(b1 + IW1_1*xp1);

% Output Layer 
a2 = b2 + LW2_1*a1;
Expression = a2;
% Output 
Expression = mapminmax_reverse(a2,y1_step1);
end

%% ===== MODULE FUNCTIONS ========
% Map Minimum and Maximum Input Processing Function
function y = mapminmax_apply(x,settings)
  y = x - settings.xoffset;
  y = y .* settings.gain;
  y = y + settings.ymin;
end

% Sigmoid Symmetric Transfer Function
function a = tansig_apply(n,~)
  a = 2 ./ (1 + exp(-2*n)) - 1;
end

% Map Minimum and Maximum Output Reverse-Processing Function
function x = mapminmax_reverse(y,settings)
  x = y - settings.ymin;
  x = x / settings.gain;
  x = x + settings.xoffset;
end