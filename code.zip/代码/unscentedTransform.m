% 毕业论文UT实现
%
function [x,w,w_tilde] = unscentedTransform(mu,C,alpha,beta)
% Generates ensembles for the Scaled Unscented Transform
%
%
%
% Inputs
%
%   mu          -   Mean of random vector
%   C           -   Covariance
%   scale       -   Scaling parameter
%
% OUTPUTS
%
%   x           -   Matrix of sigma points
%   w           -   Vector of weights corresponding to each sigma point

    n=length(mu);
    if n > 3
        kappa = 0;
    else
        kappa = 3 - n;
    end

    lambda = alpha^2*(n+kappa)-n;

    [U,S,~]=svd(C);
    
    U = U*diag(sqrt(diag(S)))*U';   %%% matrix square root of C
    scale = sqrt(lambda + n);
    
    %%% Form the scaled unscented ensemble %%%
    x = zeros(n,2*n+1);
    x(:,1) = mu;
    x(:,(2:n+1)) = repmat(mu,1,n)+scale*U;
    x(:,(n+2:2*n+1)) = repmat(mu,1,n)-scale*U;
    
    %%% Determine scaled ensemble weights %%%
    w = [scale^2-n ones(1,2*n)/2]/scale^2;
    tuning = 1-alpha^2+beta;
    w_tilde = [w(1)+tuning w(2:end)];
    w = w.';
    w_tilde = w_tilde.';
    
end

