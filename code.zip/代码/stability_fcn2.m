function [h,dh] = stability_fcn2(y,Fcn,Idx,W,mu,sigma)
% Input:
% y:    Cell Values to be put into constraint
% Fcn:   Symbolic Expression of the constraint
% Idx:      Index Struct
x_value1 = y{1};
length1 = length(x_value1);
x_value2 = y{2}*180/pi;
length2 = length(x_value2);
%x_value = [x_value1; x_value2];
x_value = [x_value1(Idx.Idx_Vm); x_value2(Idx.Idx_Va)];
x_value = x_value - mu;
W = W./sigma;
x_value = W' * x_value;
%h = double(subs(F,x,x_value));
h = Fcn(x_value);
dh = gradest(Fcn,x_value);
dh = dh * W';
%dh = double(subs(DF,x,x_value));
dh = sparse(ones(1,length(dh)),[Idx.Idx_Vm',length1+Idx.Idx_Va'],dh,1,length1+length2);
end