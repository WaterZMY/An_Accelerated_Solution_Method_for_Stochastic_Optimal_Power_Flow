function [Afun, A, Newbase] = GPCE_Generate(forecast_error, Sample)
%GPCE_GENERATE implements the dimension decomposed generalized polynomial chaos expansion
% Input:
%       forecast_error  输入数据，每一行为一维，每一列为一组观测
%       Sample  样本，每一行为一组样本，每一列为一维
% Output:
%       Afun    正交基底函数
%       A       代入样本后的正交基函数

forecast_error = forecast_error';
d = size(forecast_error, 2);    % 维数
k = input('请指定最高单项式次数：');      % 最高单项式次数
S = input('请指定最多允许的变量相关个数：');      % 最多允许的变量个数

dividers =[]; 
for i = 0 : 1 : k
    m(i+1) = nchoosek(i+d-1,d-1);
    dividers = [dividers; zeros(m(i+1),1),nchoosek((1:(i+d-1))',d-1),ones(m(i+1),1)*(i+d)];
end
a = diff(dividers,1,2)-1;
q = a > 0;
indice = find(sum(q,2)<=S);
a = a(indice,:);
a(:,:)=a(:,end:-1:1);
x = sym('x',[d 1]);

for i = 1 : size(a, 1)
    t(:,i) = prod(forecast_error.^a(i,:), 2);      
    Pbase(i) = prod(x.' .^ a(i,:));    % 初始基底函数     
end

G = t' * t/size(forecast_error,1);
Q = chol(G,"lower");
W = inv(Q);
W = tril(W)+0*triu(W,1);
Newbase = W*Pbase';         % 正交基

x = x';
Afun = matlabFunction(Newbase');
matlabFunction(Newbase');
cFun = cell(size(Sample,1),1);
cFun(cellfun(@isempty,cFun)) = {Afun};

Sample = num2cell(Sample);
for i = 1 : size(Sample,1)
        A(i, :) = cFun{i}(Sample{i,:});
end
end