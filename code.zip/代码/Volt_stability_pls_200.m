clear; clc

%% Model Preparation
% delete(gcp('nocreate'));
% parpool;
mpc = case_ACTIVSg200;
offLine = mpc.gen(mpc.gen(:, 8) == 0, 1);
mpc.bus(ismember(mpc.bus(:, 1), offLine), 2) = 1;
mpc.bus(:,12) = 1.1;
mpc.bus(:,13) = 0.9;
mpc = ext2int(mpc);
mpc = rmfield(mpc, "order");
busNo = length(mpc.bus(:, 1));
line_id = find(mpc.branch(:, 6) ~= 0);
alpha = mpc.gen(:,9)./sum(mpc.gen(:,9));
swing_bus = find(mpc.gen(:,1)==mpc.bus(find(mpc.bus(:,2)==3),1));

connect_id = [80; 95; 38; 65; 35; 105; 115; 41; 16; 8]; 
forecast = 20* ones(10, 1);  
map = zeros(busNo, size(forecast, 1));            

for i = 1 : size(forecast, 1)             
        map(connect_id(i), i) = 1;
end

%% Data Preparation
load pv_power1.mat
load pv_power2.mat
load pv_power3.mat
solar_power = [solar_power; solar_power1]*0.5;
Expectation = mean(solar_power,2);

mpc_opf = mpc;
mpc_opf.bus(:, 3) = mpc_opf.bus(:, 3) - map * Expectation;

%% Feaisble Sample Generation
[sampleIn, sampleOut, Idx, sample_control, test, testOut] = Gen_Sample(mpc_opf,20000);
I.Idx_Vm = mpc_opf.bus(:, 1);
I.Idx_Va = I.Idx_Vm(mpc_opf.bus(:, 2)~=3);
[sampleIn1, mu ,sigma] = zscore(sampleIn, 0, 2);
[sampleOut1, mu1 ,sigma1] = zscore(sampleOut, 0, 2);

%% Dimension Reduction
[XL,yl,XS,YS,beta,PCTVAR,mse,stats] = plsregress(sampleIn1',sampleOut1',49,'options',statset('UseParallel',true));
sampleIn2 = XS';

%% Train Neural Network
net = Train_NN(sampleIn2, sampleOut, 15);

%% Generate Mapping from Input to Output
[Expression, x] = NN_Expression(net);

%% Generate GPCE basis
fprintf('==================请选定最大观测数量=================\n')
num = input('请输入观测值数量：');
X = randi([1 size(solar_power, 2)], 1, num);
Sample = solar_power(:, X);
fprintf('==================请选定PCE阶数=================\n')
[Afun, A] = GPCE_Generate(solar_power, Sample');
Afuns = Afun;
As = A;

%% Solve CC AC OPF
epsilon = input('请输入违约概率： ');         
iteration = 1;              
iteration_max = 10000;      
Bound = 0.15;
stability_l = Bound;
mpopt = mpoption('verbose', 0, 'out.all', 0, 'opf.ac.solver', 'IPOPT');
F = matlabFunction(Expression, 'vars', {x});       % Input Column vector

t_start = tic;
while iteration <= iteration_max
    Fcn{iteration} = @(x) Bound - F(x);
    mpc_opf.user_constraints.nli = {{'Pg_usr', 1, 'stability_fcn2', 'stability_hess2', {'Vm','Va'}, {Fcn{iteration},I,stats.W,mu,sigma}}};
    opf_result = runopf(mpc_opf, mpopt);            % 计算运行点
    t_opf(iteration) = opf_result.et;
    if opf_result.success ~= 1
        error('第 %d 轮迭代最优潮流不收敛', iteration)
    end
    pg_operant = opf_result.gen(1:end, 2);          % 有功出力
    vg_operant = opf_result.gen(1:end, 6);          % 电压幅值

    mpc_pf = mpc;               % 潮流计算网络
    mpc_pf.gen(1:end, 2) = pg_operant;              % 给定运行点
    mpc_pf.gen(1:end, 6) = vg_operant;

    %t0 = tic;
    for i = 1 : size(Sample, 2)
            mpc_sigma{i} = mpc_pf;
            mpc_sigma{i}.gen(:, 2) = pg_operant - alpha.*sum((Sample(:,i)-Expectation));
            mpc_sigma{i}.bus(:, 3) = mpc_sigma{i}.bus(:, 3) - map * Sample(:, i);        % 考虑新能源出力
            pf_result{i} = runpf(mpc_sigma{i}, mpopt);
            
            t2 = tic;
            if pf_result{i}.success ~= 1
                error('第 %d 轮迭代，第 %d 个潮流不收敛', iteration, i)
            end

            volt(:, i) = pf_result{i}. bus(:, 8);          % 记录电压幅值
            line(:, i) = sqrt(pf_result{i}.branch(:, 14).^2 + pf_result{i}.branch(:, 15).^2);           % 记录线路视在功率
            pg(:, i) = pf_result{i}.gen(swing_bus, 2);          % 有功出力
            qg(:, i) = pf_result{i}.gen(:, 3);          % 无功出力
            J{i}=makeJac(ext2int(pf_result{i}));
            s(:,i) = min(svd(full(J{i})));
            t_end2(iteration) = toc(t2);
    end
    %t_end(iteration) = toc(t0);

    t1 = tic;

    coeff_v = A\volt';
    coeff_l = A\line';
    coeff_pg = A\pg';
    coeff_qg = A\qg';
    coeff_s = As\s';

    [volt_h, volt_l, v_estimation] = GPCE_Evaluate(solar_power, Afun, coeff_v, epsilon, 1);
    [line_h, ~, l_estimation] = GPCE_Evaluate(solar_power, Afun, coeff_l, epsilon, 1);
    [pg_h, pg_l, pg_estimation] = GPCE_Evaluate(solar_power, Afun, coeff_pg, epsilon, 1);
    [qg_h, qg_l, qg_estimation] = GPCE_Evaluate(solar_power, Afun, coeff_qg, epsilon, 1);
    [~, s_l, s_estimation] = GPCE_Evaluate(solar_power, Afuns, coeff_s, epsilon, 1);
    %t_end1(iteration) = toc(t1);

    active_id1 = find(volt_h>mpc_pf.bus(:, 12));             % 违反电压上限
    active_id2 = find(volt_l<mpc_pf.bus(:, 13));             % 违反电压下限
    active_id3 = find(line_h(line_id)>mpc_pf.branch(line_id, 6));          % 违反热容量上限
    active_id4 = find(pg_h>mpc.gen(:, 9));              % 违反出力上限
    active_id5 = find(pg_l<mpc.gen(:, 10));             % 违反出力下限
    active_id6 = find(qg_h>mpc_pf.gen(:, 4));
    active_id7 = find(qg_l<mpc_pf.gen(:, 5));
    active_id8 = find(s_l<stability_l);
    activeNo = length(active_id1) + length(active_id2) + length(active_id3) + length(active_id4)+ length(active_id5)+ ...
        length(active_id6)+ length(active_id7)+ length(active_id8);

    if activeNo == 0  || iteration == 100
        fprintf('第 %d 轮迭代，无违约，迭代结束\n', iteration);
        fprintf('最终成本为 %f 美元\n', sum(mpc.gencost(:, 5).*(opf_result.gen(1:end, 2).^2)+mpc.gencost(:, 6).*opf_result.gen(1:end, 2)+mpc.gencost(:, 7)));
        t_total = toc(t_start)
        break
    else
        iteration = iteration + 1;
    end

    delta_vh = volt_h - mpc_pf.bus(:, 12);
    delta_vh = max(delta_vh, 0);                  % 仅对违约点做更新
    delta_vl = mpc_pf.bus(:, 13) - volt_l;
    delta_vl = max(delta_vl, 0);
    delta_lh = line_h(line_id) - mpc_pf.branch(line_id, 6);
    delta_lh = max(delta_lh, 0);
    delta_qh = qg_h - mpc_pf.gen(:,4);
    delta_qh = max(delta_qh,0);
    delta_ql = mpc_pf.gen(:,5) - qg_l;
    delta_ql = max(delta_ql, 0);
    delta_ph = pg_h - mpc_pf.gen(:,9);
    delta_ph = max(delta_ph,0);
    delta_pl = mpc_pf.gen(:,10) - pg_l;
    delta_pl = max(delta_pl, 0);
    delta_sl = max(stability_l - s_l, 0);

    mpc_opf.bus(:, 12) = mpc_opf.bus(:, 12) - delta_vh;
    mpc_opf.bus(:, 13) = mpc_opf.bus(:, 13) + delta_vl;
    mpc_opf.branch(line_id, 6) = mpc_opf.branch(line_id, 6) - delta_lh;
    mpc_opf.gen(:, 4) = mpc_opf.gen(:, 4) - delta_qh;
    mpc_opf.gen(:, 5) = mpc_opf.gen(:, 5) + delta_ql;
    mpc_opf.gen(:, 9) = mpc_opf.gen(:, 9) - delta_ph;
    mpc_opf.gen(:, 10) = mpc_opf.gen(:, 10) + delta_pl;
    Bound = Bound + delta_sl;
    mpc_opf = rmfield(mpc_opf, "user_constraints");
end