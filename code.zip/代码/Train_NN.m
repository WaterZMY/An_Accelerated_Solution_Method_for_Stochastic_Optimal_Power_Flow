function net = Train_NN(X, s, num_nn)
% Solve an Input-Output Fitting problem with a Neural Network
%
%   X - input data. Row: Variables
%   s - target data. Row: Variables
x = X;
t = s;
% Choose a Training Function
% For a list of all training functions type: help nntrain
% 'trainlm' is usually fastest.
% 'trainbr' takes longer but may be better for challenging problems.
% 'trainscg' uses less memory. Suitable in low memory situations.
trainFcn = 'trainscg';  

% Create a Fitting Network
hiddenLayerSize = num_nn;
net = fitnet(hiddenLayerSize,trainFcn);
net.trainParam.min_grad = 1e-8;
net.trainParam.epochs = 15000;
% Choose Input and Output Pre/Post-Processing Functions
% For a list of all processing functions type: help nnprocess
net.input.processFcns = {'removeconstantrows','mapminmax'};
net.output.processFcns = {'removeconstantrows','mapminmax'};

% Setup Division of Data for Training, Validation, Testing
% For a list of all data division functions type: help nndivision
net.divideFcn = 'dividerand';  % Divide data randomly
net.divideMode = 'sample';  % Divide up every sample
net.divideParam.trainRatio = 70/100;
net.divideParam.valRatio = 0/100;
net.divideParam.testRatio = 30/100;

% Choose a Performance Function
% For a list of all performance functions type: help nnperformance
net.performFcn = 'mse';  % Mean Squared Error
%net.layers{1}.transferFcn = 'radbas';
% Choose Plot Functions
% For a list of all plot functions type: help nnplot
net.plotFcns = {'plotperform','plottrainstate','ploterrhist', ...
    'plotregression', 'plotfit'};
%net.layers{1}.transferFcn = 'radbas';
% Change Parameter
%net.trainParam.goal = 
% Train the Network
[net] = train(net,x,t);

% % Test the Network
% y = net(x);
% e = gsubtract(t,y);
% performance = perform(net,t,y);
% 
% % Recalculate Training, Validation and Test Performance
% trainTargets = t .* tr.trainMask{1};
% valTargets = t .* tr.valMask{1};
% testTargets = t .* tr.testMask{1};
% trainPerformance = perform(net,trainTargets,y);
% valPerformance = perform(net,valTargets,y);
% testPerformance = perform(net,testTargets,y);




