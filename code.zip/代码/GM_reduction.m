function GM1 = GM_reduction(GM)

num = GM.NumComponents;
pro = GM.ComponentProportion;
mu = GM.mu;
Sigma = GM.Sigma;
kl = 1000*ones(num,num);

for i = 1 : num-1
    for j = i+1 : num
        w1 = pro(i)/(pro(i)+pro(j));
        w2 = pro(j)/(pro(i)+pro(j));
        P12 = w1*Sigma(:,:,i)+w2*Sigma(:,:,j)+w1*w2*(mu(i,:)-mu(j,:))'*(mu(i,:)-mu(j,:));
        mu12 = w1*mu(i,:)+w2*mu(j,:);
        w12 = pro(i)+pro(j);
        kl(i,j)=w12*logdet(P12,'chol')-pro(i)*logdet(Sigma(:,:,i),'chol')-pro(j)*logdet(Sigma(:,:,j),'chol');
    end
end

[n,im]=min(kl);
[n2,im2]=min(n); %n2为最小值
i=im(1,im2);  %row为最小值所在行数
j=im2;

w1 = pro(i)/(pro(i)+pro(j));
w2 = pro(j)/(pro(i)+pro(j));
P12 = w1*Sigma(:,:,i)+w2*Sigma(:,:,j)+w1*w2*(mu(i,:)-mu(j,:))'*(mu(i,:)-mu(j,:));
mu12 = w1*mu(i,:)+w2*mu(j,:);
w12 = pro(i)+pro(j);

GM1.NumComponents = GM.NumComponents-1;
pro([i j]) = [];
pro = [pro w12];
GM1.ComponentProportion=pro;

mu([i j],:) = [];
mu = [mu;mu12];
GM1.mu = mu;

Sigma(:,:,[i j]) = [];
Sigma = cat(3,Sigma,P12);
GM1.Sigma = Sigma;

