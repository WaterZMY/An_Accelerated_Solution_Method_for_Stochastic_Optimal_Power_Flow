function [Q_h,Q_l,Estimation] = GPCE_Evaluate(forecast_error, Afun, coeff, epsilon, precision)
%GPCE_EVALUATE evaluates the quantiles through polynomial chaos expansion
% 输入：
%       forecast_error  每行为一维，每列为一组观测样本
%       Afun    正交基函数，输入行向量，输出行向量
%       coeff   系数矩阵
%       epsilon     违约概率
% 输出：
%       Q_h/Q_l     分位数，行向量

forecast_error = num2cell(forecast_error);

forecast_error1 = forecast_error';

Result = zeros(size(forecast_error1,1), size(coeff,1));
parfor i = 1 : size(forecast_error1, 1)
    Result(i, :) = Afun(forecast_error1{i,:});
end


Estimation = Result*coeff;      % 每一列为一维，每一行为一组观测样本
Q_h = quantile(Estimation, 1-epsilon, 1);         % 按列计算分位数
Q_l = quantile(Estimation, epsilon, 1);

if nargin <= 4
    Q_h = Q_h';
    Q_l = Q_l';
elseif precision == 1
    Q_h = round(Q_h'*1e10)/1e10;
    Q_l = round(Q_l'*1e10)/1e10;
end

