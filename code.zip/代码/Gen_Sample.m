function [X_state, s, Idx, X_control, X_test, s_test] = Gen_Sample(mpc, quantity)
% 生成满足可行域的足够多的样本
% 返回元素，每行代表一个变量
%% 生成采样空间
uqlab;
base = mpc.baseMVA;
Idx_Ref = mpc.bus(mpc.bus(:,2)==3, 1);
Idx_PV = mpc.bus(mpc.bus(:,2)==2, 1);
Num_PV = length(Idx_PV);
Num_Ref = length(Idx_Ref);
Num = 2*Num_PV + Num_Ref;  % Number of variables

Idx_Pg = (1 : length(mpc.gen(:,1)))';       
Idx_Pg(mpc.gen(:,1)==Idx_Ref) = [];          % Index Column vector of PV output in all generators
mpc_int = ext2int(mpc);
Idx_Vm = mpc_int.gen(:, 1);         % Index Column vector of PV and Ref voltage magnitude in all buses. The order is the same as the mpc.gen matrix
Idx = struct( ...
    'Idx_Pg', Idx_Pg, ...
    'Idx_Vm', Idx_Vm ...
    );

for i = 1 : Num_PV      % Active Output of PV bus
Input.Marginals(i).Type = 'Uniform';
Input.Marginals(i).Parameters = [mpc.gen(Idx_Pg(i),10)/base mpc.gen(Idx_Pg(i),9)/base];
end

for i = 1 : Num_PV+Num_Ref      % Voltage Magnitude of PV bus and Reference bus
Input.Marginals(i+Num_PV).Type = 'Uniform';
Input.Marginals(i+Num_PV).Parameters = [mpc.bus(Idx_Vm(i),13) mpc.bus(Idx_Vm(i),12)];
end

object = uq_createInput(Input);
X = uq_getSample(object,quantity,'LHS');
X_test = uq_getSample(object,quantity,'LHS');

idx = [];
mpopt = mpoption('verbose', 0, 'out.all', 0);
X1 = zeros(quantity, 2*length(mpc.bus(:,1)));
for i = 1 : size(X,1)
    m = mpc;
    m.gen(Idx_Pg, 2) = X(i, 1:length(Idx_Pg))'*base;
    m.gen(:, 6) = X(i, length(Idx_Pg)+1:end)';
    r = runpf(m,mpopt);

    if r.success == 1
        idx = [idx;i];
    end
    
    X1(i, :) = [r.bus(:, 8); r.bus(:, 9)];
    J = makeJac(ext2int(r));
    s(i) = min(svd(full(J)));
    if length(idx) >= 10000
        break
    end
end

X_state = X1(idx, :).';
X_state(length(mpc.bus(:,1))+find(mpc.bus(:,2)==3), :) = [];
X_control = X(idx, :)';
s = s(idx);
s = s(:).';

idx = [];
for i = 1 : size(X_test,1)
    m = mpc;
    m.gen(Idx_Pg, 2) = X_test(i, 1:length(Idx_Pg))'*base;
    m.gen(:, 6) = X_test(i, length(Idx_Pg)+1:end)';
    r = runpf(m,mpopt);

    if r.success == 1
        idx = [idx;i];
    end
    
    X2(i, :) = [r.bus(:, 8); r.bus(:, 9)];
    % J = makeJac_reduced(ext2int(r));
    J = makeJac(ext2int(r));
    s_test(i) = min(svd(full(J)));
    if length(idx) >= 10000
        break
    end
end

X_test = X2(idx, :).';
X_test(length(mpc.bus(:,1))+find(mpc.bus(:,2)==3), :) = [];
s_test = s_test(idx);
s_test = s_test(:).';


