function [d2h] = stability_hess2(y,lambda,Fcn,Idx,W,mu,sigma)
x_value1 = y{1};
length1 = length(x_value1);
x_value2 = y{2}*180/pi;
length2 = length(x_value2);
x_value = [x_value1(Idx.Idx_Vm); x_value2(Idx.Idx_Va)];
x_value = x_value - mu;
W = W./sigma;
x_value = W' * x_value;
%x_value = [x_value1; x_value2];
hess = hessian(Fcn, x_value);
%hess = double(subs(D2F,x,x_value));
hess = W * hess * W';
rowIndex = repmat([Idx.Idx_Vm; length1+Idx.Idx_Va],1,length(hess));
colIndex = repmat([Idx.Idx_Vm' length1+Idx.Idx_Va'],length(hess),1);
d2h = sparse(rowIndex,colIndex,hess,length1+length2,length1+length2);
d2h = lambda*d2h;
end