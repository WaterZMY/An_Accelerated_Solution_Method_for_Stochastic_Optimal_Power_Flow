clear; clc

%% Model Preparation
% delete(gcp('nocreate'));
% parpool;
mpc = case30;
mpc = ext2int(mpc);
mpc = rmfield(mpc, "order");
line_id = find(mpc.branch(:, 6) ~= 0);
busNo = length(mpc.bus(:, 1));
mpc.branch(:, 6) = mpc.branch(:, 6) * 1.5;
swing_bus = find(mpc.gen(:,1)==mpc.bus(find(mpc.bus(:,2)==3),1));
alpha = mpc.gen(:,9)./sum(mpc.gen(:,9));

connect_id = [24; 30; 22; 18; 29]; 
forecast = 20* ones(5, 1);  
map = zeros(busNo, size(forecast, 1));            

for i = 1 : size(forecast, 1)             
        map(connect_id(i), i) = 1;
end

%% Data Preparation
load pv_power1.mat
solar_power = solar_power*0.2;
Expectation = mean(solar_power,2);

mpc_opf = mpc;
mpc_opf.bus(:, 3) = mpc_opf.bus(:, 3) - map * Expectation;

%% Feaisble Sample Generation
[sampleIn, sampleOut, Idx,~, test, testOut] = Gen_Sample(mpc_opf,10000);
I.Idx_Vm = mpc_opf.bus(:, 1);
I.Idx_Va = I.Idx_Vm(mpc_opf.bus(:, 2)~=3);

%% Train Neural Network
net = Train_NN(sampleIn, sampleOut, 20);

%% Generate Mapping from Input to Output
[Expression, x] = NN_Expression(net);

%% GMM and Sigma Points
num_com = 16;
GMModel = fitgmdist(solar_power',num_com,'Options',statset('MaxIter',1500));
proportion = GMModel.ComponentProportion; % Row Vector

%% GMM reduction
while num_com >10
      GMModel = GM_reduction(GMModel);
      num_com = GMModel.NumComponents;
end
proportion = GMModel.ComponentProportion;

sigma = [];
w = [];
w_tilde = [];
for i = 1 : num_com
    [sig, w_temp, w_tilde_temp] = unscentedTransform(GMModel.mu(i,:)',GMModel.Sigma(:,:,i),1,2);
    sigma = [sigma sig];
    w = [w; w_temp];
    w_tilde = [w_tilde; w_tilde_temp];
end
Sample = sigma;
Sample(Sample<0)=0;

%% Solve CC AC OPF
epsilon = input('请输入违约概率： ');         
iteration = 1;              
iteration_max = 10000;      
Bound = 0.24;
stability_l = Bound;
mpopt = mpoption('verbose', 0, 'out.all', 0, 'opf.ac.solver', 'IPOPT');
F = matlabFunction(Expression, 'vars', {x});       % Input Column vector

t_start = tic;
while iteration <= iteration_max
    Fcn{iteration} = @(x) Bound - F(x);
    mpc_opf.user_constraints.nli = {{'Pg_usr', 1, 'stability_fcn1', 'stability_hess1', {'Vm','Va'}, {Fcn{iteration},I}}};
    opf_result = runopf(mpc_opf, mpopt);            % 计算运行点
    t_opf(iteration) = opf_result.et;
    if opf_result.success ~= 1
        error('第 %d 轮迭代最优潮流不收敛', iteration)
    end
    pg_operant = opf_result.gen(1:end, 2);          % 有功出力
    vg_operant = opf_result.gen(1:end, 6);          % 电压幅值

    mpc_pf = mpc;               % 潮流计算网络
    mpc_pf.gen(1:end, 2) = pg_operant;              % 给定运行点
    mpc_pf.gen(1:end, 6) = vg_operant;

    tic
    for i = 1 : size(Sample, 2)
            mpc_sigma{i} = mpc_pf;
            mpc_sigma{i}.gen(:, 2) = pg_operant - alpha.*sum((Sample(:,i)-Expectation));
            mpc_sigma{i}.bus(:, 3) = mpc_sigma{i}.bus(:, 3) - map * Sample(:, i);        % 考虑新能源出力
            pf_result{i} = runpf(mpc_sigma{i}, mpopt);

            if pf_result{i}.success ~= 1
                error('第 %d 轮迭代，第 %d 个潮流不收敛', iteration, i)
            end

            volt(:, i) = pf_result{i}. bus(:, 8);          % 记录电压幅值
            line(:, i) = sqrt(pf_result{i}.branch(:, 14).^2 + pf_result{i}.branch(:, 15).^2);           % 记录线路视在功率
            pg(:, i) = pf_result{i}.gen(swing_bus, 2);          % 有功出力
            qg(:, i) = pf_result{i}.gen(:, 3);          % 无功出力
            J{i}=makeJac(ext2int(pf_result{i}));
            s(:,i) = min(svd(full(J{i})));
    end
 
    t_end(iteration) = toc;

    num_sigma = 2*size(solar_power,1)+1;
    parfor i = 1 : num_com
        [mu_v(i,:),cov_v(i,:)] = Evaluate_SUT_statistics(volt(:,num_sigma*(i-1)+1:num_sigma*i),w(num_sigma*(i-1)+1:num_sigma*i),w_tilde(num_sigma*(i-1)+1:num_sigma*i));
        [mu_qg(i,:),cov_qg(i,:)] = Evaluate_SUT_statistics(qg(:,num_sigma*(i-1)+1:num_sigma*i),w(num_sigma*(i-1)+1:num_sigma*i),w_tilde(num_sigma*(i-1)+1:num_sigma*i)); 
        [mu_pg(i,:),cov_pg(i,:)] = Evaluate_SUT_statistics(pg(:,num_sigma*(i-1)+1:num_sigma*i),w(num_sigma*(i-1)+1:num_sigma*i),w_tilde(num_sigma*(i-1)+1:num_sigma*i));
        [mu_line(i,:),cov_line(i,:)] = Evaluate_SUT_statistics(line(:,num_sigma*(i-1)+1:num_sigma*i),w(num_sigma*(i-1)+1:num_sigma*i),w_tilde(num_sigma*(i-1)+1:num_sigma*i));
        [mu_s(i,:),cov_s(i,:)] = Evaluate_SUT_statistics(s(:,num_sigma*(i-1)+1:num_sigma*i),w(num_sigma*(i-1)+1:num_sigma*i),w_tilde(num_sigma*(i-1)+1:num_sigma*i));
    end
    
    mu = mu_v;
    covariance = reshape(cov_v',1,30,num_com);
    covariance(find(covariance<=0)) = 1e-24;
    gm = gmdistribution(mu,covariance,proportion);
    Y_v = random(gm,500000);
    v_quantile = round(quantile(Y_v,[epsilon, 1-epsilon],1).*1e10)./1e10;
    volt_l = v_quantile(1,:)';
    volt_h = v_quantile(2,:)';

    mu = mu_qg;
    covariance = reshape(cov_qg',1,6,num_com);
    covariance(find(covariance<=0)) = 1e-24;
    gm = gmdistribution(mu,covariance,proportion);
    Y_qg = random(gm,500000);
    qg_quantile = round(quantile(Y_qg,[epsilon, 1-epsilon],1).*1e10)./1e10;
    qg_l = qg_quantile(1,:)';
    qg_h = qg_quantile(2,:)';

    Y_pg = pg_operant - alpha.*sum((solar_power-Expectation),1);
    pg_h = round(quantile(Y_pg, 1-epsilon, 2)*1e10)/1e10; 
    pg_l = round(quantile(Y_pg, epsilon, 2)*1e10)/1e10;

    mu = mu_pg;
    covariance = reshape(cov_pg',1,1,num_com);
    covariance(find(covariance<=0)) = 1e-24;
    gm = gmdistribution(mu,covariance,proportion);
    Y_pg_swing = random(gm,500000);
    pg_quantile = round(quantile(Y_pg_swing,[epsilon, 1-epsilon],1).*1e10)./1e10;
    pg_l(swing_bus) = pg_quantile(1,:)';
    pg_h(swing_bus) = pg_quantile(2,:)';

    mu = mu_line;
    covariance = reshape(cov_line',1,41,num_com);
    covariance(find(covariance<=0)) = 1e-24;
    gm = gmdistribution(mu,covariance,proportion);
    Y_line = random(gm,500000);
    line_h = round(quantile(Y_line,1-epsilon,1).*1e10)./1e10;
    line_h = line_h';

    mu = mu_s;
    covariance = reshape(cov_s',1,1,num_com);
    covariance(find(covariance<=0)) = 1e-24;
    gm = gmdistribution(mu,covariance,proportion);
    Y_s = random(gm,500000);
    s_l = round(quantile(Y_s,epsilon,1).*1e10)./1e10;

    

    active_id1 = find(volt_h>mpc_pf.bus(:, 12));             % 违反电压上限
    active_id2 = find(volt_l<mpc_pf.bus(:, 13));             % 违反电压下限
    active_id3 = find(line_h(line_id)>mpc_pf.branch(line_id, 6));          % 违反热容量上限
    active_id4 = find(pg_h>mpc.gen(:, 9));              % 违反出力上限
    active_id5 = find(pg_l<mpc.gen(:, 10));             % 违反出力下限
    active_id6 = find(qg_h>mpc_pf.gen(:, 4));
    active_id7 = find(qg_l<mpc_pf.gen(:, 5));
    active_id8 = find(s_l<stability_l);
    activeNo = length(active_id1) + length(active_id2) + length(active_id3)+ length(active_id4)+ length(active_id5)+ ...
        length(active_id6)+ length(active_id7)+ length(active_id8);

    if activeNo == 0  || iteration == 100
        fprintf('第 %d 轮迭代，无违约，迭代结束\n', iteration);
        fprintf('最终成本为 %f 美元\n', sum(mpc.gencost(:, 5).*(opf_result.gen(1:end, 2).^2)+mpc.gencost(:, 6).*opf_result.gen(1:end, 2)));
        t_total = toc(t_start)
        break
    else
        iteration = iteration + 1;
    end

    delta_vh = volt_h - mpc_pf.bus(:, 12);
    delta_vh = max(delta_vh, 0);                  % 仅对违约点做更新
    delta_vl = mpc_pf.bus(:, 13) - volt_l;
    delta_vl = max(delta_vl, 0);
    delta_lh = line_h(line_id) - mpc_pf.branch(line_id, 6);
    delta_lh = max(delta_lh, 0);
    delta_qh = qg_h - mpc_pf.gen(:,4);
    delta_qh = max(delta_qh,0);
    delta_ql = mpc_pf.gen(:,5) - qg_l;
    delta_ql = max(delta_ql, 0);
    delta_ph = pg_h - mpc_pf.gen(:,9);
    delta_ph = max(delta_ph,0);
    delta_pl = mpc_pf.gen(:,10) - pg_l;
    delta_pl = max(delta_pl, 0);
    delta_sl = max(stability_l - s_l, 0);

    mpc_opf.bus(:, 12) = mpc_opf.bus(:, 12) - delta_vh;
    mpc_opf.bus(:, 13) = mpc_opf.bus(:, 13) + delta_vl;
    mpc_opf.branch(line_id, 6) = mpc_opf.branch(line_id, 6) - delta_lh;
    mpc_opf.gen(:, 4) = mpc_opf.gen(:, 4) - delta_qh;
    mpc_opf.gen(:, 5) = mpc_opf.gen(:, 5) + delta_ql;
    mpc_opf.gen(:, 9) = mpc_opf.gen(:, 9) - delta_ph;
    mpc_opf.gen(:, 10) = mpc_opf.gen(:, 10) + delta_pl;
    Bound = Bound + delta_sl;
    mpc_opf = rmfield(mpc_opf, "user_constraints");
end